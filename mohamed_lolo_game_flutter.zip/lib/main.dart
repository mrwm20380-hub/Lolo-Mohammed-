import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const MohamedLoloApp());

class MohamedLoloApp extends StatelessWidget {
  const MohamedLoloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'محمد ولولو',
      theme: ThemeData(
        fontFamily: 'sans',
        useMaterial3: true,
        colorSchemeSeed: Colors.orange,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF8FE7FF), Color(0xFFFFF3B0)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('⭐', style: TextStyle(fontSize: 72)),
                  const SizedBox(height: 8),
                  const Text(
                    'محمد ولولو',
                    style: TextStyle(
                      fontSize: 42,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF5B3A29),
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'مغامرة جمع النجوم',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 36),
                  _bigButton(
                    context,
                    'ابدأ اللعب',
                    Icons.play_arrow_rounded,
                    const Color(0xFFFF8A00),
                    () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const GamePage()),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _bigButton(
                    context,
                    'طريقة اللعب',
                    Icons.help_outline_rounded,
                    const Color(0xFF4CAF50),
                    () => showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('كيف تلعب؟', textAlign: TextAlign.right),
                        content: const Text(
                          'حرّك الشخصية يمينًا ويسارًا واجمع النجوم ⭐. '
                          'كل نجمة تزيد نقاطك. اجمع 10 نجوم للفوز بالمستوى!',
                          textAlign: TextAlign.right,
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context),
                            child: const Text('حسنًا'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _bigButton(BuildContext context, String text, IconData icon,
      Color color, VoidCallback onTap) {
    return SizedBox(
      width: 300,
      height: 66,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 34),
        label: Text(text, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
      ),
    );
  }
}

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final Random random = Random();
  double playerX = 0.5;
  int score = 0;
  int level = 1;
  bool lolo = false;
  late double starX;
  late double starY;

  @override
  void initState() {
    super.initState();
    _newStar();
  }

  void _newStar() {
    starX = 0.08 + random.nextDouble() * 0.84;
    starY = 0.12 + random.nextDouble() * 0.58;
  }

  void _move(double delta) {
    setState(() {
      playerX = (playerX + delta).clamp(0.08, 0.92);
      // لعبة مبسطة: لمس المنطقة أسفل النجمة يجمعها.
      if ((playerX - starX).abs() < 0.10 && starY > 0.45) {
        score++;
        if (score % 10 == 0) {
          level++;
          _showWin();
        }
        _newStar();
      }
    });
  }

  void _showWin() {
    Future.microtask(() {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('🎉 أحسنت!', textAlign: TextAlign.center),
          content: Text('محمد ولولو وصلوا للمستوى $level!', textAlign: TextAlign.center),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('نكمل'),
            )
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF7EDCFF), Color(0xFFC8F7B5)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.arrow_back_rounded, size: 32),
                    ),
                    Text('⭐ $score    المستوى $level',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    IconButton(
                      onPressed: () => setState(() => lolo = !lolo),
                      icon: Icon(lolo ? Icons.face_3 : Icons.face_6, size: 30),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, c) {
                    return GestureDetector(
                      onHorizontalDragUpdate: (d) => _move(d.delta.dx / c.maxWidth),
                      child: Stack(
                        children: [
                          const Positioned.fill(child: _ParkBackground()),
                          Positioned(
                            left: starX * c.maxWidth - 25,
                            top: starY * c.maxHeight - 25,
                            child: const Text('⭐', style: TextStyle(fontSize: 50)),
                          ),
                          Positioned(
                            left: playerX * c.maxWidth - 42,
                            bottom: 28,
                            child: _Character(lolo: lolo),
                          ),
                          Positioned(
                            bottom: 8,
                            left: 18,
                            right: 18,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                _control(Icons.arrow_back_rounded, () => _move(-0.08)),
                                _control(Icons.arrow_forward_rounded, () => _move(0.08)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _control(IconData icon, VoidCallback onPressed) {
    return FloatingActionButton.large(
      heroTag: icon.codePoint,
      onPressed: onPressed,
      backgroundColor: Colors.white.withOpacity(.92),
      child: Icon(icon, size: 40),
    );
  }
}

class _Character extends StatelessWidget {
  final bool lolo;
  const _Character({required this.lolo});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            color: const Color(0xFFD9A06A),
            shape: BoxShape.circle,
            border: Border.all(color: Colors.brown, width: 2),
          ),
          child: Stack(
            children: [
              Positioned(top: 22, left: 16, child: _eye()),
              Positioned(top: 22, right: 16, child: _eye()),
              Positioned(
                bottom: 15,
                left: 25,
                child: Container(
                  width: 22,
                  height: 9,
                  decoration: BoxDecoration(
                    color: Colors.pink.shade300,
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
              ),
              if (lolo)
                const Positioned(top: -8, left: 23, child: Text('🎀', style: TextStyle(fontSize: 34))),
            ],
          ),
        ),
        Container(
          width: 78,
          height: 70,
          decoration: BoxDecoration(
            color: lolo ? const Color(0xFFFF6FAE) : const Color(0xFF4F8DFF),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Center(
            child: Text(lolo ? 'لولو' : 'محمد',
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
          ),
        ),
      ],
    );
  }

  Widget _eye() => Container(
        width: 10,
        height: 13,
        decoration: const BoxDecoration(color: Colors.black, shape: BoxShape.circle),
      );
}

class _ParkBackground extends StatelessWidget {
  const _ParkBackground();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _ParkPainter());
  }
}

class _ParkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    p.color = const Color(0xFF9AE27D);
    canvas.drawRect(Rect.fromLTWH(0, size.height * .62, size.width, size.height * .38), p);

    p.color = const Color(0xFF7CCB61);
    for (int i = 0; i < 6; i++) {
      final x = size.width * (i / 5);
      canvas.drawCircle(Offset(x, size.height * .62), 45, p);
    }

    p.color = const Color(0xFF9B6B43);
    canvas.drawRect(
      Rect.fromLTWH(size.width * .12, size.height * .35, 18, size.height * .30),
      p,
    );
    p.color = const Color(0xFF45A84D);
    canvas.drawCircle(Offset(size.width * .13, size.height * .30), 70, p);
    canvas.drawCircle(Offset(size.width * .20, size.height * .34), 55, p);
    canvas.drawCircle(Offset(size.width * .08, size.height * .36), 50, p);

    p.color = const Color(0xFFE8B85B);
    canvas.drawOval(
      Rect.fromLTWH(size.width * .55, size.height * .50, size.width * .35, 45),
      p,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
