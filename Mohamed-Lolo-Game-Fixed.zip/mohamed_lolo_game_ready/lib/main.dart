import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const MohamedLoloApp());
}

class MohamedLoloApp extends StatelessWidget {
  const MohamedLoloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'محمد ولولو',
      theme: ThemeData(useMaterial3: true, fontFamily: 'sans'),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF74D8FF), Color(0xFFFFF0A8), Color(0xFF9BE58A)],
            ),
          ),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(22),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const _LogoCharacters(),
                    const SizedBox(height: 12),
                    const Text('محمد ولولو', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: Color(0xFF5B3A29))),
                    const SizedBox(height: 4),
                    const Text('مغامرة جمع النجوم ⭐', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 30),
                    _MenuButton(text: 'ابدأ اللعب', icon: Icons.play_arrow_rounded, color: const Color(0xFFFF8A00), onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => const GamePage()));
                    }),
                    const SizedBox(height: 14),
                    _MenuButton(text: 'طريقة اللعب', icon: Icons.help_outline_rounded, color: const Color(0xFF42A85A), onTap: () {
                      showDialog<void>(
                        context: context,
                        builder: (_) => const AlertDialog(
                          title: Text('🎮 طريقة اللعب', textAlign: TextAlign.center),
                          content: Text('حرّك محمد أو لولو يمينًا ويسارًا واجمع النجوم.\n\nكل نجمة = نقطة.\nكل 10 نجوم = مستوى جديد.\n\nاستخدم الأسهم أو اسحب بإصبعك على الشاشة.', textAlign: TextAlign.center),
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MenuButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _MenuButton({required this.text, required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: min(MediaQuery.sizeOf(context).width - 44, 360),
      height: 68,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 34),
        label: Text(text, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
      ),
    );
  }
}

class _LogoCharacters extends StatelessWidget {
  const _LogoCharacters();
  @override
  Widget build(BuildContext context) {
    return const Row(mainAxisSize: MainAxisSize.min, children: [
      _MiniCharacter(lolo: false),
      SizedBox(width: 18),
      Text('⭐', style: TextStyle(fontSize: 52)),
      SizedBox(width: 18),
      _MiniCharacter(lolo: true),
    ]);
  }
}

class _MiniCharacter extends StatelessWidget {
  final bool lolo;
  const _MiniCharacter({required this.lolo});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(width: 70, height: 70, decoration: const BoxDecoration(color: Color(0xFFFFD3A3), shape: BoxShape.circle), child: Center(child: Text(lolo ? '🎀' : '🧢', style: const TextStyle(fontSize: 34))),),
      Container(width: 76, height: 48, decoration: BoxDecoration(color: lolo ? const Color(0xFFFF6FAE) : const Color(0xFF4E8FFF), borderRadius: BorderRadius.circular(18)), child: Center(child: Text(lolo ? 'لولو' : 'محمد', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),),
    ]);
  }
}

class GamePage extends StatefulWidget {
  const GamePage({super.key});
  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  final Random _random = Random();
  Timer? _timer;
  double playerX = 0.5;
  double starX = 0.5;
  double starY = 0.18;
  int score = 0;
  int level = 1;
  int lives = 3;
  bool lolo = false;
  bool paused = false;
  double _dragStart = 0;

  @override
  void initState() {
    super.initState();
    _spawnStar();
    _startGameLoop();
  }

  void _startGameLoop() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 45), (_) {
      if (!mounted || paused) return;
      setState(() {
        starY += 0.006 + (level - 1) * 0.0012;
        if (starY > 0.88) {
          lives--;
          _spawnStar();
          if (lives <= 0) {
            _timer?.cancel();
            _showGameOver();
          }
        }
        if ((playerX - starX).abs() < 0.11 && starY > 0.70) {
          score++;
          if (score % 10 == 0) {
            level++;
            _showLevelUp();
          }
          _spawnStar();
        }
      });
    });
  }

  void _spawnStar() {
    starX = 0.08 + _random.nextDouble() * 0.84;
    starY = 0.08 + _random.nextDouble() * 0.20;
  }

  void _move(double delta) {
    if (paused || lives <= 0) return;
    setState(() => playerX = (playerX + delta).clamp(0.08, 0.92));
  }

  void _restart() {
    setState(() {
      score = 0;
      level = 1;
      lives = 3;
      playerX = 0.5;
      paused = false;
      _spawnStar();
    });
    _startGameLoop();
  }

  Future<void> _showLevelUp() async {
    paused = true;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('🎉 ممتاز!', textAlign: TextAlign.center),
        content: Text('وصلت للمستوى $level', textAlign: TextAlign.center),
        actions: [Center(child: TextButton(onPressed: () => Navigator.pop(context), child: const Text('نكمل اللعب')))],
      ),
    );
    if (mounted) setState(() => paused = false);
  }

  Future<void> _showGameOver() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: const Text('انتهت اللعبة 😄', textAlign: TextAlign.center),
        content: Text('جمعت $score نجمة ووصلت للمستوى $level', textAlign: TextAlign.center),
        actions: [
          Center(child: TextButton(onPressed: () { Navigator.pop(context); _restart(); }, child: const Text('العب من جديد'))),
          Center(child: TextButton(onPressed: () { Navigator.pop(context); Navigator.pop(context); }, child: const Text('الرئيسية'))),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF78DFFF), Color(0xFFB7E99B)])),
          child: SafeArea(
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
                child: Row(children: [
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded, size: 30)),
                  Expanded(child: Column(children: [Text('⭐ $score', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), Text('المستوى $level', style: const TextStyle(fontWeight: FontWeight.bold))])),
                  Text('❤️' * lives, style: const TextStyle(fontSize: 20)),
                  IconButton(onPressed: () => setState(() => paused = !paused), icon: Icon(paused ? Icons.play_arrow_rounded : Icons.pause_rounded, size: 30)),
                  IconButton(onPressed: () => setState(() => lolo = !lolo), icon: Icon(lolo ? Icons.face_3 : Icons.face_6, size: 30)),
                ]),
              ),
              Expanded(child: LayoutBuilder(builder: (context, constraints) {
                final w = constraints.maxWidth;
                final h = constraints.maxHeight;
                return GestureDetector(
                  onHorizontalDragStart: (d) => _dragStart = d.localPosition.dx,
                  onHorizontalDragUpdate: (d) {
                    final diff = d.localPosition.dx - _dragStart;
                    if (diff.abs() > 8) {
                      _move(diff / w * 0.08);
                      _dragStart = d.localPosition.dx;
                    }
                  },
                  child: Stack(children: [
                    const Positioned.fill(child: _ParkBackground()),
                    Positioned(left: starX * w - 27, top: starY * h - 27, child: const Text('⭐', style: TextStyle(fontSize: 54))),
                    if (paused) const Center(child: _PauseCard()),
                    Positioned(left: playerX * w - 43, bottom: 74, child: _GameCharacter(lolo: lolo)),
                    Positioned(bottom: 12, left: 18, right: 18, child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      _ControlButton(icon: Icons.arrow_back_rounded, onTap: () => _move(-0.08)),
                      _ControlButton(icon: Icons.arrow_forward_rounded, onTap: () => _move(0.08)),
                    ])),
                  ]),
                );
              })),
            ]),
          ),
        ),
      ),
    );
  }
}

class _PauseCard extends StatelessWidget {
  const _PauseCard();
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18), decoration: BoxDecoration(color: Colors.white.withOpacity(.92), borderRadius: BorderRadius.circular(24)), child: const Text('⏸️ اللعبة متوقفة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)));
}

class _ControlButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _ControlButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(elevation: 6, color: Colors.white.withOpacity(.94), shape: const CircleBorder(), child: InkWell(onTap: onTap, customBorder: const CircleBorder(), child: Padding(padding: const EdgeInsets.all(18), child: Icon(icon, size: 42))));
}

class _GameCharacter extends StatelessWidget {
  final bool lolo;
  const _GameCharacter({required this.lolo});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      SizedBox(width: 78, height: 78, child: Stack(alignment: Alignment.center, children: [
        Container(width: 74, height: 74, decoration: const BoxDecoration(color: Color(0xFFFFD3A3), shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 3))]), child: const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [SizedBox(width: 10), _Eye(), _Eye(), SizedBox(width: 10)])),
        Positioned(top: -3, child: Text(lolo ? '🎀' : '🧢', style: const TextStyle(fontSize: 36))),
      ])),
      Container(width: 86, height: 68, decoration: BoxDecoration(color: lolo ? const Color(0xFFFF65AA) : const Color(0xFF4B88FF), borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 5, offset: Offset(0, 3))]), child: Center(child: Text(lolo ? 'لولو' : 'محمد', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18))),),
    ]);
  }
}

class _Eye extends StatelessWidget {
  const _Eye();
  @override
  Widget build(BuildContext context) => Container(width: 10, height: 14, decoration: const BoxDecoration(color: Colors.black, shape: BoxShape.circle));
}

class _ParkBackground extends StatelessWidget {
  const _ParkBackground();
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _ParkPainter());
}

class _ParkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint();
    p.color = const Color(0xFFB9ECFF); canvas.drawRect(Offset.zero & size, p);
    p.color = const Color(0xFFFFFFFF).withOpacity(.85);
    canvas.drawOval(Rect.fromLTWH(size.width * .08, size.height * .12, 110, 42), p);
    canvas.drawOval(Rect.fromLTWH(size.width * .62, size.height * .18, 130, 45), p);
    p.color = const Color(0xFF8EDB70); canvas.drawRect(Rect.fromLTWH(0, size.height * .48, size.width, size.height * .52), p);
    p.color = const Color(0xFF6FC35B);
    for (int i = 0; i < 8; i++) canvas.drawCircle(Offset(size.width * i / 7, size.height * .49), 48, p);
    p.color = const Color(0xFFD9B36C); canvas.drawOval(Rect.fromLTWH(size.width * .28, size.height * .62, size.width * .44, size.height * .34), p);
    p.color = const Color(0xFF9A633D); canvas.drawRect(Rect.fromLTWH(size.width * .10, size.height * .31, 20, size.height * .28), p);
    p.color = const Color(0xFF3EA54D); canvas.drawCircle(Offset(size.width * .12, size.height * .27), 68, p); canvas.drawCircle(Offset(size.width * .20, size.height * .30), 52, p); canvas.drawCircle(Offset(size.width * .05, size.height * .33), 48, p);
    p.color = const Color(0xFFE9C34D); canvas.drawRect(Rect.fromLTWH(size.width * .77, size.height * .39, 8, 80), p); canvas.drawCircle(Offset(size.width * .77 + 4, size.height * .38), 24, p);
    p.color = const Color(0xFFEF6B75); canvas.drawCircle(Offset(size.width * .83, size.height * .66), 18, p); canvas.drawCircle(Offset(size.width * .87, size.height * .66), 18, p);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
