import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const MohamedLoloApp());

class MohamedLoloApp extends StatelessWidget {
  const MohamedLoloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'محمد ولولو',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF8A00)),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool lolo = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF7DDEFF), Color(0xFFFFF2B8)],
            ),
          ),
          child: SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('⭐', style: TextStyle(fontSize: 76)),
                    const SizedBox(height: 4),
                    const Text(
                      'محمد ولولو',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 44, fontWeight: FontWeight.w900, color: Color(0xFF5B3A29)),
                    ),
                    const SizedBox(height: 6),
                    const Text('مغامرة جمع النجوم', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 24),
                    _characterChoice(),
                    const SizedBox(height: 24),
                    _bigButton('ابدأ اللعب', Icons.play_arrow_rounded, const Color(0xFFFF8A00), () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => GamePage(lolo: lolo)));
                    }),
                    const SizedBox(height: 14),
                    _bigButton('طريقة اللعب', Icons.help_outline_rounded, const Color(0xFF4CAF50), _showHowToPlay),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _characterChoice() {
    return Container(
      padding: const EdgeInsets.all(6),
      decoration: BoxDecoration(color: Colors.white.withOpacity(.8), borderRadius: BorderRadius.circular(22)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _choice('محمد', false),
          _choice('لولو', true),
        ],
      ),
    );
  }

  Widget _choice(String name, bool value) {
    final selected = lolo == value;
    return GestureDetector(
      onTap: () => setState(() => lolo = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 125,
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: selected ? (value ? const Color(0xFFFF6FAE) : const Color(0xFF4F8DFF)) : Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          children: [
            Text(value ? '👧' : '👦', style: const TextStyle(fontSize: 34)),
            Text(name, style: TextStyle(color: selected ? Colors.white : Colors.black87, fontWeight: FontWeight.w900, fontSize: 17)),
          ],
        ),
      ),
    );
  }

  Widget _bigButton(String text, IconData icon, Color color, VoidCallback onTap) {
    return SizedBox(
      width: 320,
      height: 64,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 32),
        label: Text(text, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        ),
      ),
    );
  }

  void _showHowToPlay() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('🎮 كيف تلعب؟', textAlign: TextAlign.center),
        content: const Text(
          'حرّك محمد أو لولو يمينًا ويسارًا واجمع النجوم ⭐.\n\n'
          'كل نجمة = نقطة. كل 10 نجوم تفتح مستوى جديد، والمستويات الأعلى أسرع!\n\n'
          'استخدم الأسهم أو اسحب بإصبعك على الشاشة.',
          textAlign: TextAlign.right,
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا'))],
      ),
    );
  }
}

class GamePage extends StatefulWidget {
  final bool lolo;
  const GamePage({super.key, required this.lolo});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> with SingleTickerProviderStateMixin {
  final Random _random = Random();
  late bool lolo;
  late AnimationController _pulse;
  double playerX = .5;
  double starX = .5;
  double starY = .3;
  int score = 0;
  int level = 1;
  int starsInLevel = 0;
  bool paused = false;

  @override
  void initState() {
    super.initState();
    lolo = widget.lolo;
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 850))..repeat(reverse: true);
    _newStar();
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  void _newStar() {
    starX = .10 + _random.nextDouble() * .80;
    starY = .18 + _random.nextDouble() * .48;
  }

  void _move(double delta) {
    if (paused) return;
    setState(() {
      playerX = (playerX + delta).clamp(.08, .92).toDouble();
      final closeEnough = (playerX - starX).abs() < .105;
      if (closeEnough && starY > .18 && starY < .72) {
        score++;
        starsInLevel++;
        _newStar();
        if (starsInLevel >= 10) {
          level++;
          starsInLevel = 0;
          _showLevelDialog();
        }
      }
    });
  }

  void _showLevelDialog() {
    Future.microtask(() {
      if (!mounted) return;
      showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: const Text('🎉 أحسنت!', textAlign: TextAlign.center),
          content: Text('وصلت للمستوى $level!\nجاهز للتحدي التالي؟', textAlign: TextAlign.center),
          actions: [Center(child: TextButton(onPressed: () => Navigator.pop(context), child: const Text('نكمل اللعب')))],
        ),
      );
    });
  }

  void _reset() {
    setState(() {
      playerX = .5;
      score = 0;
      level = 1;
      starsInLevel = 0;
      paused = false;
      _newStar();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              _topBar(),
              Expanded(
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onHorizontalDragUpdate: (details) => _move(details.delta.dx / constraints.maxWidth),
                      child: Stack(
                        clipBehavior: Clip.hardEdge,
                        children: [
                          const Positioned.fill(child: _ParkBackground()),
                          if (!paused)
                            AnimatedBuilder(
                              animation: _pulse,
                              builder: (_, __) => Positioned(
                                left: starX * constraints.maxWidth - 25,
                                top: starY * constraints.maxHeight - 25,
                                child: Transform.scale(scale: 1 + _pulse.value * .12, child: const Text('⭐', style: TextStyle(fontSize: 50))),
                              ),
                            ),
                          Positioned(
                            left: playerX * constraints.maxWidth - 42,
                            bottom: 74,
                            child: IgnorePointer(child: _Character(lolo: lolo)),
                          ),
                          if (paused)
                            const Center(child: _PauseCard()),
                          Positioned(bottom: 10, left: 16, right: 16, child: _controls()),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
      child: Row(
        children: [
          IconButton(tooltip: 'رجوع', onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded, size: 30)),
          Expanded(
            child: Column(
              children: [
                Text('⭐ $score', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                Text('المستوى $level', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          IconButton(tooltip: 'إيقاف مؤقت', onPressed: () => setState(() => paused = !paused), icon: Icon(paused ? Icons.play_arrow_rounded : Icons.pause_rounded, size: 30)),
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'character') setState(() => lolo = !lolo);
              if (value == 'reset') _reset();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'character', child: Text('تغيير الشخصية')),
              PopupMenuItem(value: 'reset', child: Text('إعادة اللعبة')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _controls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _control(Icons.arrow_back_rounded, () => _move(-.075)),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          decoration: BoxDecoration(color: Colors.white.withOpacity(.86), borderRadius: BorderRadius.circular(16)),
          child: Text('$starsInLevel / 10 ⭐', style: const TextStyle(fontWeight: FontWeight.w900)),
        ),
        _control(Icons.arrow_forward_rounded, () => _move(.075)),
      ],
    );
  }

  Widget _control(IconData icon, VoidCallback onPressed) {
    return SizedBox(
      width: 68,
      height: 68,
      child: FloatingActionButton(
        heroTag: icon.codePoint,
        onPressed: onPressed,
        backgroundColor: Colors.white.withOpacity(.94),
        foregroundColor: Colors.black87,
        child: Icon(icon, size: 38),
      ),
    );
  }
}

class _PauseCard extends StatelessWidget {
  const _PauseCard();
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 8,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18),
        child: Column(mainAxisSize: MainAxisSize.min, children: const [
          Icon(Icons.pause_circle_filled_rounded, size: 54),
          SizedBox(height: 6),
          Text('اللعبة متوقفة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        ]),
      ),
    );
  }
}

class _Character extends StatelessWidget {
  final bool lolo;
  const _Character({required this.lolo});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 84,
      height: 142,
      child: Column(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                width: 76,
                height: 76,
                decoration: BoxDecoration(color: const Color(0xFFFFC58A), shape: BoxShape.circle, border: Border.all(color: const Color(0xFF8B5E3C), width: 2)),
                child: Stack(children: [
                  const Positioned(top: 23, left: 18, child: _Eye()),
                  const Positioned(top: 23, right: 18, child: _Eye()),
                  Positioned(bottom: 15, left: 27, child: Container(width: 22, height: 8, decoration: BoxDecoration(color: Colors.pinkAccent, borderRadius: BorderRadius.circular(20)))),
                ]),
              ),
              if (lolo) const Positioned(top: -11, left: 22, child: Text('🎀', style: TextStyle(fontSize: 35))),
              if (!lolo) const Positioned(top: -4, left: 17, right: 17, child: Text('🧢', textAlign: TextAlign.center, style: TextStyle(fontSize: 34))),
            ],
          ),
          Container(
            width: 82,
            height: 62,
            decoration: BoxDecoration(color: lolo ? const Color(0xFFFF6FAE) : const Color(0xFF4F8DFF), borderRadius: BorderRadius.circular(22), boxShadow: const [BoxShadow(blurRadius: 5, offset: Offset(0, 3), color: Colors.black26)]),
            alignment: Alignment.center,
            child: Text(lolo ? 'لولو' : 'محمد', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
          ),
        ],
      ),
    );
  }
}

class _Eye extends StatelessWidget {
  const _Eye();
  @override
  Widget build(BuildContext context) => Container(width: 10, height: 13, decoration: const BoxDecoration(color: Colors.black, shape: BoxShape.circle));
}

class _ParkBackground extends StatelessWidget {
  const _ParkBackground();
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _ParkPainter());
}

class _ParkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..style = PaintingStyle.fill;
    p.color = const Color(0xFF87DFFF);
    canvas.drawRect(Offset.zero & size, p);

    p.color = Colors.white.withOpacity(.75);
    for (final cloud in [Offset(size.width * .18, size.height * .13), Offset(size.width * .73, size.height * .19)]) {
      canvas.drawCircle(cloud, 24, p);
      canvas.drawCircle(cloud.translate(28, 4), 18, p);
      canvas.drawCircle(cloud.translate(-26, 6), 17, p);
    }

    p.color = const Color(0xFF9AE27D);
    canvas.drawRect(Rect.fromLTWH(0, size.height * .55, size.width, size.height * .45), p);
    p.color = const Color(0xFF75C85D);
    for (int i = 0; i < 7; i++) canvas.drawCircle(Offset(size.width * i / 6, size.height * .55), 45, p);

    // Tree
    p.color = const Color(0xFF99623D);
    canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(size.width * .12, size.height * .28, 22, size.height * .34), const Radius.circular(8)), p);
    p.color = const Color(0xFF42A94D);
    canvas.drawCircle(Offset(size.width * .15, size.height * .25), 65, p);
    canvas.drawCircle(Offset(size.width * .23, size.height * .30), 52, p);
    canvas.drawCircle(Offset(size.width * .08, size.height * .31), 46, p);

    // Path
    p.color = const Color(0xFFE9C477);
    canvas.drawOval(Rect.fromLTWH(size.width * .36, size.height * .62, size.width * .40, size.height * .48), p);

    // Flowers
    p.color = const Color(0xFFFFD23F);
    for (int i = 0; i < 10; i++) {
      final x = size.width * (.05 + (i % 5) * .22);
      final y = size.height * (.64 + (i % 2) * .15);
      canvas.drawCircle(Offset(x, y), 4, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
